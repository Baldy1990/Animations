Helldivers-inspired fan animation pack for Momentum firmware.
Three original 128x64 monochrome loops, 16 frames each, 6 fps.
Copy Helldivers into SD Card/asset_packs, then select it in Momentum > Interface > Graphics.
Unofficial fan artwork; no game assets or code included.
